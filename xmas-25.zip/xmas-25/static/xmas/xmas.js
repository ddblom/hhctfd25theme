/* =========================================================================
   CTFd Xmas Theme — clean twinkle + adjustable snow (lightweight)
   -------------------------------------------------------------------------
   TWEAK ME (top section only)
   ========================================================================= */
const XMAS = {
  // Features
  ENABLE_LIGHTS: true,
  ENABLE_SNOW:   true,

  // Respect device constraints (set to false to force full effects)
  RESPECT_SAVE_DATA: true,  // navigator.connection.saveData
  RESPECT_LOW_END:   true,  // <=4 cores or <=4GB deviceMemory

  // ---------------- Lights ----------------
  BULBS_MIN: 16,
  BULBS_MAX: 30,
  BULB_SPACING_PX: 44,             // width / spacing -> bulb count

  // Twinkle: clean = uniform duration/amplitude, only phase varies
  TWINKLE_DURATION_S: 3.2,         // all bulbs use this duration (clean look)
  TWINKLE_MIN_OPACITY: 0.38,       // 0..1 (lower = brighter swing)
  FORCE_SMOOTH_TWINKLE: true,      // ignore low-end fallback for lights

  // ---------------- Snow ----------------
  // SNOW_MODE: "AUTO" uses area & density; "FIXED" uses an exact count.
  SNOW_MODE: "AUTO",               // "AUTO" | "FIXED"
  FIXED_FLAKES: 60,                 // used when SNOW_MODE === "FIXED"

  // AUTO preset (used when SNOW_MODE === "AUTO")
  AUTO: {
    SCALE: 0.50,    // logical canvas scale (0.35–0.65). Higher = more pixels (heavier)
    DENSITY: 20000, // logical px^2 per flake. LOWER = MORE flakes
    MAX: 72,        // hard cap
    MIN: 14,        // minimum
    FPS: 22         // 18–30 is fine; lower saves more
  },

  // Frame pacing & adaptive trim (for both modes)
  FPS_FIXED: 22,                  // FPS when SNOW_MODE === "FIXED"
  ADAPTIVE_TRIM_ENABLED: true,    // turn off if you want to keep all flakes no matter what
  ADAPT_TRIM_MS: 11,              // if a frame draw exceeds this, trim flakes
  ADAPT_GROW_MS: 4,               // if cheaper than this, add a flake (to target)
  ADAPT_CUT_FACTOR: 0.9,          // trim multiplier each time

  // Internals (only change if you have conflicts)
  IDS:    { TOGGLE: "xmas-toggle", LIGHTS: "xmas-lights", SNOW: "xmas-snow", STYLE: "xmas-style" },
  CLASSES:{ OFF: "xmas-off", LOW_END: "xmas-low-end", BULB: "bulb" },
  STORAGE_KEY: "xmasEffects"
};

/* =========================================================================
   Implementation (no need to edit below)
   ========================================================================= */
(() => {
  const R = document.documentElement;

  // --- Environment
  const prefersReduced = mm("(prefers-reduced-motion: reduce)");
  const saveData  = !!(navigator.connection && navigator.connection.saveData);
  const lowEnd    = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) ||
                    (navigator.deviceMemory && navigator.deviceMemory <= 4);
  const respectSD = XMAS.RESPECT_SAVE_DATA;
  const respectLE = XMAS.RESPECT_LOW_END;
  const effectiveLowEnd = (respectSD && saveData) || (respectLE && lowEnd);

  // Only used for CSS fallbacks if you keep external CSS (safe to leave on)
  R.classList.toggle(XMAS.CLASSES.LOW_END, effectiveLowEnd);

  // --- Toggle state
  const getOn = () => {
    const v = localStorage.getItem(XMAS.STORAGE_KEY);
    if (v === "off") return false;
    if (v === "on")  return true;
    return !prefersReduced; // default: follow reduce-motion
  };
  const setOn = (on) => {
    localStorage.setItem(XMAS.STORAGE_KEY, on ? "on" : "off");
    R.classList.toggle(XMAS.CLASSES.OFF, !on);
  };

  // --- Minimal CSS (twinkle keyframes + safe defaults)
  injectStyle(`
    @keyframes xmasTwinkleClean {
      0%,100% { opacity: var(--min, .38); }
      50%     { opacity: 1; }
    }
    /* The bulbs already have shape from your CSS; here we only ensure animation is defined */
    /* We set the animation inline per-bulb to override any previous animation definitions cleanly. */
  `);

  // --- Toggle UI
  function injectToggle(){
    if (document.getElementById(XMAS.IDS.TOGGLE)) return;
    const b = document.createElement("button");
    b.id = XMAS.IDS.TOGGLE;
    b.type = "button";
    b.innerHTML = `<span class="dot" aria-hidden="true"></span> Festive effects`;
    b.classList.toggle("off", !getOn());
    b.setAttribute("aria-pressed", getOn() ? "true" : "false");
    b.title = "Toggle festive effects";
    b.addEventListener("click", () => {
      const next = !getOn();
      setOn(next);
      b.classList.toggle("off", !getOn());
      b.setAttribute("aria-pressed", getOn() ? "true" : "false");
      getOn() ? startEffects() : stopEffects();
    });
    document.body.appendChild(b);
  }

  // --- Lights
  let lightsEl = null, lightsResizeTO = null;
  function buildLights(){
    if (!XMAS.ENABLE_LIGHTS || lightsEl || R.classList.contains(XMAS.CLASSES.OFF)) return;
    const navbar = document.querySelector(".navbar");
    if (!navbar) return;
    if (getComputedStyle(navbar).position === "static") navbar.style.position = "relative";

    lightsEl = document.createElement("div");
    lightsEl.id = XMAS.IDS.LIGHTS;
    navbar.appendChild(lightsEl);
    layoutLights();

    window.addEventListener("resize", onResizeLights, { passive: true });
  }
  function onResizeLights(){
    clearTimeout(lightsResizeTO);
    lightsResizeTO = setTimeout(() => { layoutLights(); adjustBodyOffset(); }, 120);
  }
  function layoutLights(){
    if (!lightsEl) return;
    while (lightsEl.firstChild) lightsEl.removeChild(lightsEl.firstChild);

    const hostW = (lightsEl.parentElement || document.body).clientWidth || window.innerWidth;
    const count = clamp(Math.floor(hostW / XMAS.BULB_SPACING_PX), XMAS.BULBS_MIN, XMAS.BULBS_MAX);

    // Clean twinkle: same duration & min; random phase only
    const dur   = XMAS.TWINKLE_DURATION_S;
    const minOp = clamp(XMAS.TWINKLE_MIN_OPACITY, 0, 1);
    const stepped = (!XMAS.FORCE_SMOOTH_TWINKLE && effectiveLowEnd); // optional fallback

    for (let i=0; i<count; i++){
      const el = document.createElement("div");
      el.className = XMAS.CLASSES.BULB;   // your CSS shapes it

      // inline animation overrides any "animation: ..." from site CSS = clean behavior
      el.style.setProperty("--min", String(minOp));
      el.style.setProperty("--dur", dur + "s");
      const delay = -(Math.random() * dur).toFixed(2); // random phase
      el.style.animation = `xmasTwinkleClean var(--dur) ${stepped ? "steps(2,end)" : "ease-in-out"} infinite`;
      el.style.animationDelay = `${delay}s`;
      el.style.willChange = "opacity";

      lightsEl.appendChild(el);
    }
  }
  function destroyLights(){
    window.removeEventListener("resize", onResizeLights);
    if (lightsEl && lightsEl.parentNode) lightsEl.parentNode.removeChild(lightsEl);
    lightsEl = null;
  }

  // Keep content below fixed navbar + lights
  function adjustBodyOffset(){
    const navbar = document.querySelector(".navbar");
    if (!navbar) return;
    const navH = navbar.offsetHeight;
    let overhang = 0;
    if (lightsEl){
      const nb = navbar.getBoundingClientRect();
      const lb = lightsEl.getBoundingClientRect();
      overhang = Math.max(0, lb.bottom - nb.bottom);
    }
    document.body.style.paddingTop = `${Math.ceil(navH + overhang)}px`;
  }

  // --- Snow
  let snowCanvas = null, ctx = null, rafID = null;
  let flakes = [];
  let lastTS = 0;
  let isScrolling = false;
  let targetCount = 0;
  let onResizeSnow = null, onScroll = null, onVisibility = null;

  // pre-render sprites (tiny offscreen canvases)
  const sprites = { s: sprite(3), m: sprite(5), l: sprite(7) };

  function startSnow(){
    if (!XMAS.ENABLE_SNOW || snowCanvas || R.classList.contains(XMAS.CLASSES.OFF)) return;

    snowCanvas = document.createElement("canvas");
    snowCanvas.id = XMAS.IDS.SNOW;
    snowCanvas.style.width = "100%";
    snowCanvas.style.height = "100%";
    document.body.appendChild(snowCanvas);
    ctx = snowCanvas.getContext("2d", { alpha: true });
    ctx.imageSmoothingEnabled = true;

    const useFixed = XMAS.SNOW_MODE === "FIXED";
    const conf = XMAS.AUTO;
    const DPR = 1; // fixed for softness + perf

    onResizeSnow = () => {
      const w = Math.max(1, Math.floor(window.innerWidth  * (useFixed ? 0.45 : conf.SCALE)));
      const h = Math.max(1, Math.floor(window.innerHeight * (useFixed ? 0.45 : conf.SCALE)));
      snowCanvas.width  = Math.floor(w * DPR);
      snowCanvas.height = Math.floor(h * DPR);
      ctx.setTransform(1,0,0,1,0,0);
      ctx.scale(DPR, DPR);

      if (useFixed){
        targetCount = Math.max(0, Math.round(XMAS.FIXED_FLAKES));
      } else {
        const area = w * h;
        targetCount = Math.min(conf.MAX, Math.max(conf.MIN, Math.floor(area / conf.DENSITY)));
      }
      // grow/shrink pool to target
      while (flakes.length < targetCount) flakes.push(makeFlake(w, h));
      if (flakes.length > targetCount) flakes.length = targetCount;
    };
    window.addEventListener("resize", onResizeSnow, { passive: true });
    onResizeSnow();

    // pause while scrolling to avoid jank
    let sTO = null;
    onScroll = () => {
      isScrolling = true;
      clearTimeout(sTO);
      sTO = setTimeout(() => { isScrolling = false; }, 160);
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    // pause when hidden
    onVisibility = () => {
      if (document.hidden){
        if (rafID) cancelAnimationFrame(rafID);
        rafID = null;
      } else if (!rafID && snowCanvas){
        lastTS = 0;
        rafID = requestAnimationFrame(loop);
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    lastTS = 0;
    rafID = requestAnimationFrame(loop);

    function loop(ts){
      const fps = (XMAS.SNOW_MODE === "FIXED") ? XMAS.FPS_FIXED : conf.FPS;
      if (ts && lastTS && (ts - lastTS) < (1000 / fps)) { rafID = requestAnimationFrame(loop); return; }
      lastTS = ts || performance.now();

      if (isScrolling) { rafID = requestAnimationFrame(loop); return; }

      const frameStart = performance.now();
      const w = snowCanvas.width, h = snowCanvas.height;

      ctx.clearRect(0, 0, w, h);
      const t = lastTS / 1000;

      for (let i=0; i<flakes.length; i++){
        const f = flakes[i];
        f.y += f.sy;
        f.x += Math.sin(t + f.phase) * f.drift;
        if (f.y > h + 8){ f.y = -10; f.x = Math.random() * w; }

        ctx.globalAlpha = f.a;
        const size = f.r * 2;
        const spr = f.r < 1.2 ? sprites.s : (f.r < 1.8 ? sprites.m : sprites.l);
        ctx.drawImage(spr, f.x - size/2, f.y - size/2, size, size);
      }

      if (XMAS.ADAPTIVE_TRIM_ENABLED){
        const spent = performance.now() - frameStart;
        if (spent > XMAS.ADAPT_TRIM_MS && flakes.length > 1){
          flakes.length = Math.max(1, Math.floor(flakes.length * XMAS.ADAPT_CUT_FACTOR));
        } else if (spent < XMAS.ADAPT_GROW_MS && flakes.length < targetCount){
          flakes.push(makeFlake(w, h));
        }
      }

      rafID = requestAnimationFrame(loop);
    }
  }

  function stopSnow(){
    if (rafID) cancelAnimationFrame(rafID);
    rafID = null;
    flakes = [];
    lastTS = 0;

    if (snowCanvas && snowCanvas.parentNode) snowCanvas.parentNode.removeChild(snowCanvas);
    snowCanvas = null; ctx = null;

    window.removeEventListener("resize", onResizeSnow, { passive: true });
    window.removeEventListener("scroll", onScroll, { passive: true });
    document.removeEventListener("visibilitychange", onVisibility);
  }

  // --- Helpers (snow)
  function sprite(d){
    const c = document.createElement("canvas");
    const g = c.getContext("2d");
    const s = d * 2 + 2;
    c.width = s; c.height = s;
    const r = d;
    const grad = g.createRadialGradient(s/2, s/2, 0, s/2, s/2, r);
    grad.addColorStop(0, "rgba(255,255,255,1)");
    grad.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grad;
    g.beginPath(); g.arc(s/2, s/2, r, 0, Math.PI*2); g.fill();
    return c;
  }
  function makeFlake(w, h){
    const r = Math.random() * 1.4 + 0.6;
    return {
      x: Math.random() * w,
      y: Math.random() * h,
      r,
      sy: r * (0.18 + Math.random()*0.45),
      drift: 0.45 + Math.random()*0.75,
      a: 0.6 + Math.random()*0.25,
      phase: Math.random()*Math.PI*2
    };
  }

  // --- Utils
  function injectStyle(css){
    if (document.getElementById(XMAS.IDS.STYLE)) return;
    const s = document.createElement("style");
    s.id = XMAS.IDS.STYLE; s.textContent = css;
    document.head.appendChild(s);
  }
  function mm(q){ try { return !!(window.matchMedia && window.matchMedia(q).matches); } catch { return false; } }
  function clamp(v, a, b){ return Math.max(a, Math.min(b, v)); }

  // --- Lifecycle
  function startEffects(){
    if (R.classList.contains(XMAS.CLASSES.OFF)) return;
    buildLights();
    startSnow();
    adjustBodyOffset();
  }
  function stopEffects(){
    destroyLights();
    stopSnow();
    adjustBodyOffset();
  }

  // --- Boot
  /* setOn(getOn());
  if (document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", () => { injectToggle(); startEffects(); setTimeout(adjustBodyOffset, 60); });
  } else {
    injectToggle(); startEffects(); setTimeout(adjustBodyOffset, 60);
  } */
  // --- Boot (always on, no toggle)
  document.addEventListener("DOMContentLoaded", () => {
    startEffects();
    setTimeout(adjustBodyOffset, 60);
  });
})();
